package com.cg.wallet.bean;

public class WalletAccount {

	private String userName;
	private double balance;
	private String password;
	static int i=0;
	
	public WalletAccount() {
		// TODO Auto-generated constructor stub
	}

	public WalletAccount(String userName, double balance,String password) {
		super();
		this.userName = userName;
		this.balance = balance;
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}


	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "WalletAccount [userName=" + userName + ", balance=" + balance + ", password=" + password + "]";
	}

	
}
