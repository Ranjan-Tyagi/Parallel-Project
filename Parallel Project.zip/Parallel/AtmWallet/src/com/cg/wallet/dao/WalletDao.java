package com.cg.wallet.dao;


import java.util.*;

import com.cg.wallet.bean.WalletAccount;
import com.cg.wallet.bean.WalletTransaction;
import com.cg.wallet.exception.WalletException;

public interface WalletDao {
	public WalletAccount createAccount(WalletAccount account)throws WalletException ;
	public double showBalance(String username,String password)throws WalletException ;
	public WalletAccount deposit(String username,double amount)throws WalletException ;
	public WalletAccount withdraw(String username,String password,double amount)throws WalletException ;
	public List<WalletAccount> fundTransfer(String fromUserName,String fromPassword,String toUserName,double amount)throws WalletException;
	public List<WalletTransaction> printTransactions(String username,String password)throws WalletException ;

}
