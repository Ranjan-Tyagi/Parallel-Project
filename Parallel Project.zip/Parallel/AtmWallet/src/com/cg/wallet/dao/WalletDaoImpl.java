package com.cg.wallet.dao;




import java.time.LocalDateTime;
import java.util.*;

import com.cg.wallet.Db.Staticdb;
import com.cg.wallet.bean.WalletAccount;
import com.cg.wallet.bean.WalletTransaction;
import com.cg.wallet.exception.WalletException;

public class WalletDaoImpl implements WalletDao{
	
	@Override
	public WalletAccount createAccount(WalletAccount account) throws WalletException {
		// TODO Auto-generated method stub
		if(Staticdb.getWMap().containsKey(account.getUserName()))
			throw new WalletException("Username exists Already");
		else
		{		Staticdb.getWMap().put(account.getUserName(), account);
				Staticdb.getTMap().put(account.getUserName(),new ArrayList<WalletTransaction>());			
				Staticdb.getTMap().get(account.getUserName()).add(new WalletTransaction(account.getUserName(),"Created",account.getBalance(),account.getBalance(),LocalDateTime.now()));
		}
		return account;
	}

	@Override
	public double showBalance(String username,String password)  throws WalletException {
		// TODO Auto-generated method stub
		if(validateUser(username, password))
		 return Staticdb.getWMap().get(username).getBalance();
		
		return 0;
	}

	@Override
	public WalletAccount deposit(String username, double amount) throws WalletException  {
		// TODO Auto-generated method stub
		if(!Staticdb.getWMap().containsKey(username))
			throw new WalletException("Username incorrect,No such account exist");
		else
		{
			Staticdb.getWMap().get(username).setBalance(Staticdb.getWMap().get(username).getBalance()+amount);
			double fbalance =Staticdb.getWMap().get(username).getBalance()+amount;
			Staticdb.getTMap().get(username).add(new WalletTransaction(username, "Deposit", amount, fbalance, LocalDateTime.now()));
			return Staticdb.getWMap().get(username);
		}	
	}

	@Override
	public WalletAccount withdraw(String username,String password, double amount)  throws WalletException {
		// TODO Auto-generated method stub
		double balance=Staticdb.getWMap().get(username).getBalance();
			if(!Staticdb.getWMap().containsKey(username))
				throw new WalletException("Username incorrect,No such account exist");
			else if(!Staticdb.getWMap().get(username).getPassword().equals(password))
				throw new WalletException("Wrong Password!! Access Denied");
			else
				if(balance-amount>=0)
					throw new WalletException("Insufficient Balance");
				else
				{
					Staticdb.getWMap().get(username).setBalance(balance-amount);
					double fbalance =Staticdb.getWMap().get(username).getBalance()-amount;
					Staticdb.getTMap().get(username).add(new WalletTransaction(username, "Withdraw", amount, fbalance, LocalDateTime.now()));
					return Staticdb.getWMap().get(username);
				}
	}

	@Override
	public List<WalletAccount> fundTransfer(String fromUserName,String fromPassword,String toUserName,double amount) throws WalletException  {
		// TODO Auto-generated method stub
		if(validateUser(fromUserName, fromPassword));
		else if(!Staticdb.getWMap().containsKey(toUserName))
			throw new WalletException("Invalid Receiver,No such account exist");
		else
		{
			withdraw(fromUserName,fromPassword, amount);
			double fbalance =Staticdb.getWMap().get(fromUserName).getBalance()-amount;
			deposit(toUserName, amount);
			double fbalance1 =Staticdb.getWMap().get(toUserName).getBalance()+amount;
			Staticdb.getTMap().get(fromUserName).add(new WalletTransaction(fromUserName, "Transfer to  ", amount, fbalance, LocalDateTime.now()));
			Staticdb.getTMap().get(fromUserName).add(new WalletTransaction(toUserName, "Get By Transfer ", amount, fbalance1, LocalDateTime.now()));
			List<WalletAccount> wList=new ArrayList<WalletAccount>();
			wList.add(Staticdb.getWMap().get(fromUserName));
			wList.add(Staticdb.getWMap().get(toUserName));
			return wList;
		}
		return null;
	}

	@Override
	public List<WalletTransaction> printTransactions(String username,String password) throws WalletException  {
		// TODO Auto-generated method stub
		//Map<String ,List<WalletTransaction>> temp=new HashMap<String,List< WalletTransaction>>(StaticDB.getTMap());
		
		List<WalletTransaction> li=new ArrayList<WalletTransaction>(Staticdb.getTMap().getOrDefault(username, new ArrayList<WalletTransaction>()));
		//System.out.println(li);
		if(validateUser(username, password))
		{	return li;
			}
		else 
			return null;
	}
	private static boolean validateUser(String username,String password) throws WalletException{
		if(Staticdb.getWMap().size()!=0&&!Staticdb.getWMap().containsKey(username))
			{throw new WalletException("Username incorrect,No such account exist");}
		else if(!Staticdb.getWMap().get(username).getPassword().equals(password))
			{throw new WalletException("Wrong Password!! Access Denied");}
		else
			return true;
	}
}

