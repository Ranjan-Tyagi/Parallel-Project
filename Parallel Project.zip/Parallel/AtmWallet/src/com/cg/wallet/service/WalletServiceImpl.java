package com.cg.wallet.service;



import java.util.*;

import com.cg.wallet.bean.WalletAccount;
import com.cg.wallet.bean.WalletTransaction;
import com.cg.wallet.dao.WalletDao;
import com.cg.wallet.dao.WalletDaoImpl;
import com.cg.wallet.exception.WalletException;

public class WalletServiceImpl implements WalletService {
	WalletDao dao=new WalletDaoImpl();
	public WalletServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public WalletAccount createAccount(WalletAccount account)throws WalletException {
		// TODO Auto-generated method stub
		return dao.createAccount(account);
	}

	@Override
	public double showBalance(String username,String password) throws WalletException {
		// TODO Auto-generated method stub
		return dao.showBalance(username,password);
	}

	@Override
	public WalletAccount deposit(String username,double amount) throws WalletException {
		// TODO Auto-generated method stub
		return dao.deposit(username, amount);
	}

	@Override
	public WalletAccount withdraw(String username,String password, double amount) throws WalletException {
		// TODO Auto-generated method stub
		return dao.withdraw(username,password, amount);
	}

	@Override
	public List<WalletAccount> fundTransfer(String fromUserName,String fromPassword,String toUserName,double amount)throws WalletException  {
		// TODO Auto-generated method stub
		return dao.fundTransfer(fromUserName,fromPassword, toUserName,amount);
	}

	@Override
	public List<WalletTransaction> printTransactions(String username,String password) throws WalletException {
		// TODO Auto-generated method stub
		return dao.printTransactions(username,password);
	}
}
