package com.cg.wallet.Db;
import java.time.LocalDateTime;
import java.util.*;

import com.cg.wallet.bean.WalletAccount;
import com.cg.wallet.bean.WalletTransaction;
import com.cg.wallet.exception.WalletException;


public class Staticdb {
	private static HashMap<String, com.cg.wallet.bean.WalletAccount> wMap=new HashMap<String, WalletAccount>();
	private static HashMap<String, List<WalletTransaction>> tMap=new HashMap<String,List<WalletTransaction>>();
	
	static
	{
		wMap.put("User1",new WalletAccount("Ranjan",0,"Tyagi"));
		wMap.put("User2",new WalletAccount("Tyagi",0,"Ranjan"));
		tMap.put("User1",new ArrayList<WalletTransaction>());
		tMap.put("User2",new ArrayList<WalletTransaction>());
		tMap.get("User1").add(new WalletTransaction("User1", "Deposit",1000.0 , 1000,LocalDateTime.now()));
		wMap.get("User1").setBalance(1000);
		tMap.get("User1").add(new WalletTransaction("User1", "Withdraw",500 , 500,LocalDateTime.now() ));
		wMap.get("User1").setBalance(500);
		tMap.get("User1").add(new WalletTransaction("User1", "Transfer(debit)",250 , 250,LocalDateTime.now() ));
		tMap.get("User2").add(new WalletTransaction("User2", "Transfer(credit)",250 , 250,LocalDateTime.now() ));
		wMap.get("User1").setBalance(250);
		wMap.get("User2").setBalance(250);
	}
	public static HashMap<String, WalletAccount> getWMap()
	{
		return wMap;
	}
	
	public static HashMap<String,List<WalletTransaction>> getTMap()
	{  //System.out.println(tMap);
		return tMap;
	}

}
