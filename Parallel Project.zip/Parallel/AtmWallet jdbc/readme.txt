create table wallet(
username varchar2(30),
password varchar2(30),
balance number(10,2)
 );
 
 

 
create table transaction(
username varchar2(30),
 type varchar2(30),
 amount number(20),
 fbalance number(10,2),
 d varchar2(40)
 );
 
