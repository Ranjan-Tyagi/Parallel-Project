package com.cg.skwallet.ui;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.skwallet.bean.WalletAccount;
import com.cg.skwallet.bean.WalletTransaction;
import com.cg.skwallet.exception.WalletException;
import com.cg.skwallet.service.WalletService;
import com.cg.skwallet.service.WalletServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WalletService service=new WalletServiceImpl();
		Scanner sc=new Scanner(System.in); 
		String control="yes";
		String username,password;
		double amount;
		WalletAccount wallet=new WalletAccount();
		do
		{   System.out.println("*******  ATM WALLET   ******");
	     	System.out.println("                      ");
			System.out.println("1-Create Account");
			System.out.println("2-Show Balance");
			System.out.println("3-Deposit");
			System.out.println("4-Withdraw");
			System.out.println("5-Fund Transfer");
			System.out.println("6-Print Transaction");
			System.out.println("7-Exit");
			System.out.println("*****************************");
			
			System.out.print("Enter your choice:");
			int choice=sc.nextInt();
			switch(choice)
			{
				case 1: boolean co=false;
					do{
						System.out.println("Enter your User Name and password");
				try {
					wallet=service.createAccount(new WalletAccount(sc.next(),0,sc.next()));
					System.out.println("Account with Username= "+wallet.getUserName()
							+" created.");
					co=true;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					co=false;
				}}while(!co);
						break;
				case 2: co=false;
				do{
					System.out.println("Enter Username and password");
						username=sc.next();
						password=sc.next();
						try{
							System.out.println("Balance:"+service.showBalance(username, password));
							co=true;
						}catch(Exception e){
							System.out.println(e.getMessage());
							//e.printStackTrace();
							co=false;
						}
				}while(!co);
				break;
				case 3: co=false;
					do{
					System.out.println("Enter Username and amount");
						username=sc.next();
						amount=sc.nextDouble();
						try
						{
							wallet=service.deposit(username, amount);
							System.out.println("Rs. "+amount+" deposited successfully");
							System.out.println("Updated account details");
							//System.out.println(w);
							co=true;
						}
						catch(Exception e)
						{  System.out.println(e.getMessage());
							co=false;
						}
					}while(!co);
						break;
				case 4: co=false;
				do{
						System.out.println("Enter Username,password and amount");
						username=sc.next();
						password=sc.next();
						amount=sc.nextDouble();
						try
						{
							wallet=service.withdraw(username, password, amount);
							System.out.println("Rs. "+amount+" withdrawn successfully");
							System.out.println("Updated account details");
							//System.out.println(w);
							co=true;
						}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
							co=false;
						}
				}while(!co);	
						break;
				case 5: co=false;
					do{	System.out.println("Enter Username,password and amount");
						username=sc.next();
						password=sc.next();
						amount=sc.nextDouble();
						System.out.println("Enter receiver's username");
						String toUserName=sc.next();
						try{
							boolean b=service.fundTransfer(username, password, toUserName, amount);
							if(b)	{
							   System.out.println("Updated bank account ");
							   co=true;}			
							else 
								co=false;
						}catch(Exception e) {
							co=false;
							System.out.println(e.getMessage());
						}
					}while(!co);
						break;
				case 6: System.out.println("Enter Username and password");
						username=sc.next();
						password=sc.next();
						try{
							ResultSet rs=service.printTransactions(username, password);
							while (rs.next()) {
								String Data ="      "+ rs.getString(1) + "     :     " + rs.getString(2) + "   :   " + rs.getDouble(3) + "    :     " + rs.getDouble(4)+
										rs.getString(5);
								System.out.println(Data);
							}
							//System.out.println(rs);
							//System.out.println(service.printTransactions(username, password));
						}catch (Exception e) {
							// TODO: handle exception
							System.out.println(e.getMessage());
						}
						break;
				case 7: System.exit(0);
			}
			System.out.println("Enter Yes to continue or anything to exit");
			control=sc.next();
		}while(control.equalsIgnoreCase("YES") );
	}
	}


